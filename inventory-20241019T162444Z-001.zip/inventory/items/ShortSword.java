package rpg.inventory.items;

public class ShortSword extends Weapon {

    public ShortSword() {
        super("Espada Corta", 10,10);
    }
}
