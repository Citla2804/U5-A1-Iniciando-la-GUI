package rpg.inventory.items;

public class PlateArmor extends Armor {

    public PlateArmor() {
        super("Armadura de Placas", 15,15);
    }
}
