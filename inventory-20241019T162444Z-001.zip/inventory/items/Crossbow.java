package rpg.inventory.items;

public class Crossbow extends Weapon {

    public Crossbow() {
        super("Ballesta", 14,10);
    }
}
