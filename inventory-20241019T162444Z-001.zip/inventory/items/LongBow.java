package rpg.inventory.items;

public class LongBow extends Weapon {

    public LongBow() {
        super("Arco Largo", 12,10);
    }
}
