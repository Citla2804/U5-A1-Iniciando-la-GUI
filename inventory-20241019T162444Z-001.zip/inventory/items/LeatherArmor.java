package rpg.inventory.items;

public class LeatherArmor extends Armor {

    public LeatherArmor() {
        super("Armadura de Cuero", 5,6);
    }
}
